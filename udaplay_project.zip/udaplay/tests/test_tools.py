import json
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from langchain_core.documents import Document  # noqa: E402

from src import tools  # noqa: E402


def _fake_doc(name="Pokémon Red", platform="Game Boy"):
    return Document(
        page_content=f"Title: {name}\nPlatform: {platform}\nGenre: RPG\n"
        f"Publisher: Nintendo\nRelease Year: 1996\nDescription: A classic.",
        metadata={
            "id": "001",
            "name": name,
            "platform": platform,
            "genre": "RPG",
            "publisher": "Nintendo",
            "release_year": 1996,
        },
    )


def test_retrieve_game_formats_results():
    fake_store = MagicMock()
    with patch.object(tools, "_get_vector_store", return_value=fake_store), \
         patch.object(tools, "similarity_search", return_value=[(_fake_doc(), 0.12)]):
        raw = tools.retrieve_game.invoke({"query": "Pokémon Red platform"})

    data = json.loads(raw)
    assert data["query"] == "Pokémon Red platform"
    assert len(data["results"]) == 1
    assert data["results"][0]["name"] == "Pokémon Red"
    assert data["results"][0]["platform"] == "Game Boy"


def test_evaluate_retrieval_empty_context_is_low_confidence():
    empty_retrieval = json.dumps({
        "query": "Unknown Game XYZ",
        "results": [],
        "formatted_context": "No matching games found in the internal database.",
    })
    raw = tools.evaluate_retrieval.invoke(
        {"query": "Unknown Game XYZ", "retrieved_docs": empty_retrieval}
    )
    data = json.loads(raw)
    assert data["is_sufficient"] is False
    assert data["confidence_score"] == 0.0


def test_evaluate_retrieval_uses_llm_for_nonempty_context():
    good_retrieval = json.dumps({
        "query": "When was Pokémon Red launched?",
        "results": [{"name": "Pokémon Red", "platform": "Game Boy", "release_year": 1996}],
        "formatted_context": "Title: Pokémon Red\nPlatform: Game Boy\nRelease Year: 1996",
    })

    fake_llm = MagicMock()
    fake_llm.invoke.return_value = MagicMock(
        content=json.dumps(
            {"confidence_score": 0.95, "is_sufficient": True, "reasoning": "Directly matches."}
        )
    )

    with patch.object(tools, "_get_eval_llm", return_value=fake_llm):
        raw = tools.evaluate_retrieval.invoke(
            {"query": "When was Pokémon Red launched?", "retrieved_docs": good_retrieval}
        )

    data = json.loads(raw)
    assert data["is_sufficient"] is True
    assert data["confidence_score"] == 0.95


def test_game_web_search_formats_results():
    fake_client = MagicMock()
    fake_client.search.return_value = {
        "answer": "Rockstar is reportedly working on GTA 6.",
        "results": [
            {"title": "Rockstar news", "content": "GTA 6 announced...", "url": "https://example.com"}
        ],
    }

    with patch.object(tools, "_get_tavily_client", return_value=fake_client):
        raw = tools.game_web_search.invoke({"query": "What is Rockstar Games working on right now?"})

    data = json.loads(raw)
    assert "GTA 6" in data["formatted_context"]
    assert len(data["raw_results"]) == 1
