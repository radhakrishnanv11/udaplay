import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.data_loader import load_documents, load_raw_games  # noqa: E402

DATA_PATH = Path(__file__).resolve().parent.parent / "data" / "games.json"


def test_load_raw_games_returns_records():
    records = load_raw_games(DATA_PATH)
    assert len(records) == 10
    names = {r.Name for r in records}
    assert "Pokémon Red" in names
    assert "Elden Ring" in names


def test_records_to_documents_content():
    documents = load_documents(DATA_PATH)
    assert len(documents) == 10
    doc = next(d for d in documents if d.metadata["name"] == "Pokémon Red")
    assert "Game Boy" in doc.page_content
    assert doc.metadata["publisher"] == "Nintendo"
    assert doc.metadata["release_year"] == 1996
