import json
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src import agents, tools  # noqa: E402
from src.graph import build_graph  # noqa: E402


def _mock_retrieve_sufficient(inputs):
    return json.dumps({
        "query": inputs["query"],
        "results": [{
            "id": "001", "name": "Pokémon Red", "platform": "Game Boy",
            "genre": "RPG", "publisher": "Nintendo", "description": "Classic.",
            "release_year": 1996, "similarity_score": 0.05,
        }],
        "formatted_context": "Title: Pokémon Red\nPlatform: Game Boy\nRelease Year: 1996",
    })


def _mock_retrieve_empty(inputs):
    return json.dumps({
        "query": inputs["query"], "results": [],
        "formatted_context": "No matching games found in the internal database.",
    })


def _mock_evaluate_high(inputs):
    return json.dumps({"confidence_score": 0.9, "is_sufficient": True, "reasoning": "Good match."})


def _mock_evaluate_low(inputs):
    return json.dumps({"confidence_score": 0.1, "is_sufficient": False, "reasoning": "No data."})


def _mock_web_search(inputs):
    return json.dumps({
        "query": inputs["query"],
        "formatted_context": "Summary: Rockstar is working on GTA 6.",
        "raw_results": [{"title": "News", "content": "GTA 6", "url": "https://example.com"}],
    })


def _mock_llm_response(*args, **kwargs):
    return MagicMock(content="Pokémon Red launched in 1996 on the Game Boy.")


def test_graph_takes_internal_db_path_when_confident():
    fake_retrieve = MagicMock(side_effect=_mock_retrieve_sufficient)
    fake_evaluate = MagicMock(side_effect=_mock_evaluate_high)

    with patch("src.agents.retrieve_game") as mock_retrieve_tool, \
         patch("src.agents.evaluate_retrieval") as mock_evaluate_tool, \
         patch("src.agents.ChatOpenAI") as mock_chat_cls:
        mock_retrieve_tool.invoke = fake_retrieve
        mock_evaluate_tool.invoke = fake_evaluate
        mock_chat_cls.return_value.invoke.side_effect = _mock_llm_response

        graph = build_graph()
        final_state = graph.invoke({
            "query": "When was Pokémon Red launched, and on what platform?",
            "reasoning_trace": [],
            "used_web_search": False,
        })

    answer = final_state["final_answer"]
    assert answer["source"] == "Internal Game Database"
    assert "1996" in answer["answer"] or "Game Boy" in answer["answer"]


def test_graph_falls_back_to_web_search_when_low_confidence():
    fake_retrieve = MagicMock(side_effect=_mock_retrieve_empty)
    fake_evaluate = MagicMock(side_effect=_mock_evaluate_low)
    fake_web_search = MagicMock(side_effect=_mock_web_search)

    with patch("src.agents.retrieve_game") as mock_retrieve_tool, \
         patch("src.agents.evaluate_retrieval") as mock_evaluate_tool, \
         patch("src.agents.game_web_search") as mock_web_tool, \
         patch("src.agents.ChatOpenAI") as mock_chat_cls:
        mock_retrieve_tool.invoke = fake_retrieve
        mock_evaluate_tool.invoke = fake_evaluate
        mock_web_tool.invoke = fake_web_search
        mock_chat_cls.return_value.invoke.side_effect = _mock_llm_response

        graph = build_graph()
        final_state = graph.invoke({
            "query": "What is Rockstar Games working on right now?",
            "reasoning_trace": [],
            "used_web_search": False,
        })

    answer = final_state["final_answer"]
    assert answer["source"] == "Web Search via Tavily"
    assert final_state["used_web_search"] is True
