"""
One-off script to build the FAISS vector store from data/games.json and
persist it to disk (UDAPLAY_FAISS_DIR, default: faiss_index_udaplay/).

Usage:
    python scripts/build_index.py
    python scripts/build_index.py --data path/to/other_games.json
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.config import settings  # noqa: E402
from src.data_loader import load_documents  # noqa: E402
from src.logger import get_logger  # noqa: E402
from src.vector_store import build_vector_store, similarity_search  # noqa: E402

logger = get_logger("build_index")


def main() -> None:
    parser = argparse.ArgumentParser(description="Build the UdaPlay FAISS index.")
    parser.add_argument(
        "--data",
        default="data/games.json",
        help="Path to the raw game JSON dataset (default: data/games.json)",
    )
    args = parser.parse_args()

    settings.validate()

    logger.info("Step 1/3: Loading and validating raw game data...")
    documents = load_documents(args.data)

    logger.info("Step 2/3: Building and persisting FAISS index...")
    vector_store = build_vector_store(documents)

    logger.info("Step 3/3: Verifying retrieval with a smoke-test query...")
    test_query = "When was Pokémon Red launched, and on what platform?"
    results = similarity_search(vector_store, test_query, k=2)
    for doc, score in results:
        logger.info("  match (score=%.4f): %s", score, doc.metadata.get("name"))

    logger.info("FAISS index build complete. Ready for the agent workflow.")


if __name__ == "__main__":
    main()
