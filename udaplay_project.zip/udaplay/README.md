# UdaPlay — Multi-Agent RAG Research Agent

UdaPlay is an intelligent gaming research agent. It answers questions from
executives, analysts, and gamers by first checking an internal FAISS
knowledge base (RAG) and, only when that context is insufficient, falling
back to a live Tavily web search — always citing which source(s) it used.

The system is implemented as **four cooperating agents** wired together
with a LangGraph `StateGraph`:

```
[ User Query ]
      |
      v
[ RetrieverAgent ] --(FAISS similarity search)--> [ Internal Context ]
      |
      v
[ EvaluatorAgent ] --(LLM-judged confidence score)-->
      |
  +---+-------------------------+
  v (sufficient)                v (insufficient)
  |                     [ WebSearchAgent ] (Tavily fallback)
  |                             |
  +-------------+---------------+
                v
      [ SynthesizerAgent ] --> Structured, cited final answer
```

## Project Layout

```
udaplay/
├── config.env.example      # copy to config.env and fill in real keys
├── requirements.txt
├── data/
│   └── games.json          # sample internal game dataset
├── src/
│   ├── config.py            # env loading + validation
│   ├── logger.py            # centralized logging (console + rotating file)
│   ├── schemas.py           # Pydantic v2 models shared across agents/tools
│   ├── data_loader.py        # JSON -> validated records -> LangChain Documents
│   ├── vector_store.py       # FAISS build / persist / reload / search
│   ├── tools.py              # retrieve_game, evaluate_retrieval, game_web_search
│   ├── agents.py             # 4 agent node functions + routing logic
│   └── graph.py              # LangGraph StateGraph wiring it all together
├── scripts/
│   └── build_index.py        # standalone script: build + persist the FAISS index
├── notebooks/
│   ├── Udaplay_01_solution_project.ipynb   # Part 1: RAG pipeline
│   └── Udaplay_02_solution_project.ipynb   # Part 2: multi-agent workflow
├── tests/                    # pytest suite (fully mocked, no API calls needed)
├── main.py                   # CLI entrypoint (single-shot or interactive REPL)
└── logs/                     # created at runtime; udaplay.log
```

## Setup

1. **Install dependencies** (Python 3.11+):

   ```bash
   pip install -r requirements.txt
   ```

2. **Configure credentials**: copy the example env file and fill in your keys.

   ```bash
   cp config.env.example config.env
   # then edit config.env:
   #   OPENAI_API_KEY="sk-..."
   #   TAVILY_API_KEY="tvly-..."
   #   OPENAI_BASE_URL="https://openai.vocareum.com/v1"
   ```

3. **Build the FAISS index** (Part 1 deliverable — also runnable from Notebook 01):

   ```bash
   python scripts/build_index.py
   ```

   This loads `data/games.json`, embeds it with `text-embedding-3-small`,
   and persists the index to `faiss_index_udaplay/`.

## Running the Agent

**Single-shot query:**

```bash
python main.py "When was Pokémon Red launched, and on what platform?"
```

**Interactive REPL:**

```bash
python main.py
```

**Notebooks** (matches the rubric's expected deliverables):

```bash
jupyter notebook notebooks/Udaplay_01_solution_project.ipynb
jupyter notebook notebooks/Udaplay_02_solution_project.ipynb
```

## Running the Tests

The test suite mocks all LLM / embedding / Tavily calls, so it runs fully
offline with no API keys required:

```bash
pytest tests/ -v
```

## Logging

Every agent/tool step is logged with `src/logger.py`:

- Console: human-readable, level controlled by `UDAPLAY_LOG_LEVEL` (default `INFO`).
- File: `logs/udaplay.log` (rotating, always `DEBUG` level) — a full audit
  trail of every retrieval, evaluation score, web-search fallback, and
  synthesized answer, useful for reviewing agent reasoning traces.

## Decision Logic

1. `RetrieverAgent` queries FAISS via `retrieve_game`.
2. `EvaluatorAgent` scores the retrieval via `evaluate_retrieval`
   (`confidence_score`, `is_sufficient`, `reasoning`).
3. If `is_sufficient` **and** `confidence_score >= UDAPLAY_CONFIDENCE_THRESHOLD`
   (default `0.6`) → route straight to `SynthesizerAgent`.
4. Otherwise → route to `WebSearchAgent` (`game_web_search`, Tavily), then
   `SynthesizerAgent`.
5. `SynthesizerAgent` produces a `FinalAnswer` (Pydantic model) citing
   `Internal Game Database`, `Web Search via Tavily`, or both.

## Sample Test Scenarios (from the requirements doc)

| # | Query | Expected Path |
|---|-------|----------------|
| 1 | "When was Pokémon Red launched, and on what platform?" | FAISS hit → high confidence → internal citation |
| 2 | "What is Rockstar Games working on right now?" | FAISS miss/low confidence → Tavily fallback → web citation |
| 3 | "When was God of War Ragnarok released?" | FAISS hit (sample data includes it) or web fallback if absent |

All three are exercised in `notebooks/Udaplay_02_solution_project.ipynb`.

## Extending the Project (bonus ideas from the spec)

- **Long-term memory**: after a successful `WebSearchAgent` fallback, embed
  and upsert the new facts back into the FAISS index (`vector_store.py` already
  exposes `build_vector_store` / a `FAISS.add_documents` call would slot in
  directly after `SynthesizerAgent`).
- **Structured outputs**: already implemented — `FinalAnswer` in `schemas.py`.
- **Metadata filtering**: FAISS `similarity_search` accepts a `filter=`
  argument keyed on the `publisher` / `platform` metadata already stored on
  each `Document`.
- **Multi-turn memory**: swap `graph.compile()` for
  `graph.compile(checkpointer=...)` with a LangGraph checkpointer (e.g.
  `MemorySaver` or a Postgres/Redis-backed one) to persist state across turns.
