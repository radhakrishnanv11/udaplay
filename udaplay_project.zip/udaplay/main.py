"""
UdaPlay CLI entrypoint.

Usage:
    python main.py                       # interactive REPL
    python main.py "your question here"  # single-shot query
"""

from __future__ import annotations

import json
import sys

from src.config import settings
from src.graph import run_query
from src.logger import get_logger

logger = get_logger("main")


def print_answer(answer: dict) -> None:
    print("\n" + "=" * 70)
    print(f"Q: {answer['query']}")
    print("-" * 70)
    print(answer["answer"])
    if answer.get("key_details"):
        print("\nKey Details:")
        for k, v in answer["key_details"].items():
            if v:
                print(f"  - {k}: {v}")
    print(f"\nSource: {answer['source']}")
    if answer.get("confidence_score") is not None:
        print(f"Retrieval confidence: {answer['confidence_score']:.2f}")
    print("=" * 70 + "\n")


def main() -> None:
    settings.validate()

    if len(sys.argv) > 1:
        query = " ".join(sys.argv[1:])
        answer = run_query(query)
        print_answer(answer)
        return

    print("UdaPlay AI Research Agent — type a question, or 'exit' to quit.\n")
    while True:
        try:
            query = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            break

        if not query:
            continue
        if query.lower() in {"exit", "quit"}:
            print("Goodbye!")
            break

        try:
            answer = run_query(query)
            print_answer(answer)
        except Exception as exc:  # noqa: BLE001
            logger.exception("Error while processing query: %s", exc)
            print(f"Sorry, something went wrong: {exc}")


if __name__ == "__main__":
    main()
