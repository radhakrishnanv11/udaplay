"""
Centralized logging configuration for UdaPlay.

Every module calls `get_logger(__name__)` to obtain a logger that writes to
both the console (human-readable) and a rotating log file (for audits /
debugging agent decision traces). Configure the log level and log file
via the UDAPLAY_LOG_LEVEL / UDAPLAY_LOG_FILE environment variables.
"""

from __future__ import annotations

import logging
import os
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path

_CONFIGURED = False


def _configure_root_logger() -> None:
    global _CONFIGURED
    if _CONFIGURED:
        return

    log_level_name = os.getenv("UDAPLAY_LOG_LEVEL", "INFO").upper()
    log_level = getattr(logging, log_level_name, logging.INFO)

    log_file = os.getenv("UDAPLAY_LOG_FILE", "logs/udaplay.log")
    log_path = Path(log_file)
    log_path.parent.mkdir(parents=True, exist_ok=True)

    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)-28s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    root = logging.getLogger("udaplay")
    root.setLevel(log_level)
    root.propagate = False

    if not root.handlers:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(formatter)
        console_handler.setLevel(log_level)
        root.addHandler(console_handler)

        file_handler = RotatingFileHandler(
            log_path, maxBytes=2_000_000, backupCount=3, encoding="utf-8"
        )
        file_handler.setFormatter(formatter)
        file_handler.setLevel(logging.DEBUG)  # keep full trace in the file
        root.addHandler(file_handler)

    _CONFIGURED = True


def get_logger(name: str) -> logging.Logger:
    """Return a namespaced logger, e.g. `udaplay.tools.retrieve_game`."""
    _configure_root_logger()
    return logging.getLogger(f"udaplay.{name}")
