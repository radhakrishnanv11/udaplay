"""
Data loading & validation for UdaPlay.

Reads the raw video-game JSON dataset, validates each record with Pydantic,
and converts it into LangChain `Document` objects ready for embedding.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import List

from langchain_core.documents import Document
from pydantic import BaseModel, Field, ValidationError

from src.logger import get_logger

logger = get_logger("data_loader")


class RawGameRecord(BaseModel):
    """Schema for a single entry in data/games.json."""

    id: str | None = None
    Name: str
    Platform: str
    Genre: str | None = None
    Publisher: str | None = None
    Description: str | None = None
    YearOfRelease: int | None = Field(default=None)


def load_raw_games(json_path: str | Path) -> List[RawGameRecord]:
    """Load and validate the raw JSON file into a list of RawGameRecord."""
    json_path = Path(json_path)
    logger.info("Loading raw game data from %s", json_path)

    if not json_path.exists():
        raise FileNotFoundError(f"Game data file not found: {json_path}")

    with open(json_path, "r", encoding="utf-8") as f:
        raw_items = json.load(f)

    logger.info("Read %d raw records. Validating with Pydantic...", len(raw_items))

    records: List[RawGameRecord] = []
    errors = 0
    for idx, item in enumerate(raw_items):
        try:
            records.append(RawGameRecord(**item))
        except ValidationError as exc:
            errors += 1
            logger.warning("Skipping invalid record at index %d: %s", idx, exc)

    logger.info(
        "Validation complete: %d valid records, %d rejected.", len(records), errors
    )
    return records


def records_to_documents(records: List[RawGameRecord]) -> List[Document]:
    """Convert validated game records into LangChain Documents for embedding."""
    logger.info("Converting %d records into Document objects...", len(records))

    documents: List[Document] = []
    for record in records:
        content = (
            f"Title: {record.Name}\n"
            f"Platform: {record.Platform}\n"
            f"Genre: {record.Genre or 'Unknown'}\n"
            f"Publisher: {record.Publisher or 'Unknown'}\n"
            f"Release Year: {record.YearOfRelease or 'Unknown'}\n"
            f"Description: {record.Description or 'No description available.'}"
        )
        metadata = {
            "id": record.id,
            "name": record.Name,
            "platform": record.Platform,
            "genre": record.Genre,
            "publisher": record.Publisher,
            "release_year": record.YearOfRelease,
        }
        documents.append(Document(page_content=content, metadata=metadata))

    logger.info("Created %d Document objects.", len(documents))
    return documents


def load_documents(json_path: str | Path) -> List[Document]:
    """Convenience wrapper: load raw JSON straight into Documents."""
    records = load_raw_games(json_path)
    return records_to_documents(records)
