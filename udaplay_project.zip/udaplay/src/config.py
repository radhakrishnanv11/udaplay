"""
Environment & configuration loading for UdaPlay.

Loads `config.env` (falling back to `.env`), validates that required API
keys are present, and exposes a single `settings` object used throughout
the project so that no other module talks to `os.getenv` directly.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

from src.logger import get_logger

logger = get_logger("config")

PROJECT_ROOT = Path(__file__).resolve().parent.parent


def _load_env() -> None:
    """Load config.env (preferred) or .env from the project root."""
    candidates = [PROJECT_ROOT / "config.env", PROJECT_ROOT / ".env"]
    for candidate in candidates:
        if candidate.exists():
            load_dotenv(candidate, override=False)
            logger.info("Loaded environment variables from %s", candidate.name)
            return
    logger.warning(
        "No config.env or .env file found in %s. "
        "Falling back to variables already present in the shell environment.",
        PROJECT_ROOT,
    )


_load_env()


@dataclass(frozen=True)
class Settings:
    openai_api_key: str
    tavily_api_key: str
    openai_base_url: str
    llm_model: str
    embedding_model: str
    faiss_dir: str
    confidence_threshold: float
    top_k: int
    log_level: str

    def validate(self) -> None:
        missing = []
        if not self.openai_api_key:
            missing.append("OPENAI_API_KEY")
        if not self.tavily_api_key:
            missing.append("TAVILY_API_KEY")
        if missing:
            message = (
                f"Missing required environment variable(s): {', '.join(missing)}. "
                f"Copy config.env.example to config.env and fill in real values."
            )
            logger.error(message)
            raise EnvironmentError(message)
        logger.info("Environment validation passed. All required keys are present.")


def load_settings() -> Settings:
    settings = Settings(
        openai_api_key=os.getenv("OPENAI_API_KEY", ""),
        tavily_api_key=os.getenv("TAVILY_API_KEY", ""),
        openai_base_url=os.getenv("OPENAI_BASE_URL", "https://openai.vocareum.com/v1"),
        llm_model=os.getenv("UDAPLAY_LLM_MODEL", "gpt-4o-mini"),
        embedding_model=os.getenv("UDAPLAY_EMBEDDING_MODEL", "text-embedding-3-small"),
        faiss_dir=os.getenv("UDAPLAY_FAISS_DIR", "faiss_index_udaplay"),
        confidence_threshold=float(os.getenv("UDAPLAY_CONFIDENCE_THRESHOLD", "0.6")),
        top_k=int(os.getenv("UDAPLAY_TOP_K", "4")),
        log_level=os.getenv("UDAPLAY_LOG_LEVEL", "INFO"),
    )
    logger.debug("Loaded settings: %s", {**settings.__dict__, "openai_api_key": "***", "tavily_api_key": "***"})
    return settings


# Singleton settings instance used across the project.
settings = load_settings()
