"""
Pydantic (v2) schemas shared across UdaPlay's tools and agents.

Using structured schemas lets each agent hand off validated, typed data to
the next agent instead of passing around loosely-formatted strings.
"""

from __future__ import annotations

from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, Field


class SourceType(str, Enum):
    INTERNAL_DB = "Internal Game Database"
    WEB_SEARCH = "Web Search via Tavily"
    HYBRID = "Internal Game Database + Web Search via Tavily"


class GameRecord(BaseModel):
    """A single game document as stored in / retrieved from FAISS."""

    id: Optional[str] = None
    name: str
    platform: str
    genre: Optional[str] = None
    publisher: Optional[str] = None
    description: Optional[str] = None
    release_year: Optional[int] = None
    similarity_score: Optional[float] = Field(
        default=None, description="FAISS similarity score (lower = closer, L2 distance)."
    )


class RetrievalResult(BaseModel):
    """Output of the Retriever Agent's `retrieve_game` tool call."""

    query: str
    results: List[GameRecord] = Field(default_factory=list)
    formatted_context: str = Field(
        default="", description="Human-readable block of the retrieved game(s)."
    )

    @property
    def is_empty(self) -> bool:
        return len(self.results) == 0


class EvaluationResult(BaseModel):
    """Output of the Evaluator Agent's `evaluate_retrieval` tool call."""

    confidence_score: float = Field(ge=0.0, le=1.0)
    is_sufficient: bool
    reasoning: str


class WebSearchResult(BaseModel):
    """Output of the Web Search Agent's `game_web_search` tool call."""

    query: str
    formatted_context: str = ""
    raw_results: List[dict] = Field(default_factory=list)


class FinalAnswer(BaseModel):
    """The structured final answer returned to the user."""

    query: str
    answer: str
    key_details: dict = Field(default_factory=dict)
    source: SourceType
    confidence_score: Optional[float] = None
    reasoning_trace: List[str] = Field(default_factory=list)
