"""
FAISS vector store lifecycle management for UdaPlay.

Responsible for:
  - Building a FAISS index from Documents (OpenAI text-embedding-3-small).
  - Persisting the index to local disk.
  - Reloading a persisted index across runs.
  - A thin similarity-search helper used by the retrieve_game tool.
"""

from __future__ import annotations

from pathlib import Path
from typing import List, Tuple

from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
from langchain_openai import OpenAIEmbeddings

from src.config import settings
from src.logger import get_logger

logger = get_logger("vector_store")


def get_embeddings() -> OpenAIEmbeddings:
    logger.debug("Instantiating OpenAIEmbeddings(model=%s)", settings.embedding_model)
    return OpenAIEmbeddings(
        model=settings.embedding_model,
        openai_api_key=settings.openai_api_key,
        openai_api_base=settings.openai_base_url,
    )


def build_vector_store(documents: List[Document], persist_dir: str | Path | None = None) -> FAISS:
    """Embed `documents` and build a fresh FAISS index, then persist it."""
    persist_dir = Path(persist_dir or settings.faiss_dir)
    logger.info("Building FAISS index from %d documents...", len(documents))

    embeddings = get_embeddings()
    vector_store = FAISS.from_documents(documents, embedding=embeddings)

    persist_dir.mkdir(parents=True, exist_ok=True)
    vector_store.save_local(str(persist_dir))
    logger.info("FAISS index built and persisted to '%s'.", persist_dir)

    return vector_store


def load_vector_store(persist_dir: str | Path | None = None) -> FAISS:
    """Reload a previously persisted FAISS index from disk."""
    persist_dir = Path(persist_dir or settings.faiss_dir)
    logger.info("Loading FAISS index from '%s'...", persist_dir)

    if not persist_dir.exists():
        raise FileNotFoundError(
            f"No FAISS index found at '{persist_dir}'. Run scripts/build_index.py first."
        )

    embeddings = get_embeddings()
    vector_store = FAISS.load_local(
        str(persist_dir),
        embeddings=embeddings,
        allow_dangerous_deserialization=True,  # safe: index built locally by this project
    )
    logger.info("FAISS index loaded successfully.")
    return vector_store


def get_or_build_vector_store(
    documents: List[Document], persist_dir: str | Path | None = None
) -> FAISS:
    """Load the index if it already exists on disk, otherwise build it."""
    persist_dir = Path(persist_dir or settings.faiss_dir)
    index_file = persist_dir / "index.faiss"

    if index_file.exists():
        logger.info("Existing FAISS index detected at '%s'.", persist_dir)
        return load_vector_store(persist_dir)

    logger.info("No existing FAISS index found. Building a new one.")
    return build_vector_store(documents, persist_dir)


def similarity_search(
    vector_store: FAISS, query: str, k: int | None = None
) -> List[Tuple[Document, float]]:
    """Run a top-k similarity search, returning (Document, score) pairs."""
    k = k or settings.top_k
    logger.info("Running similarity search for query=%r (k=%d)", query, k)

    results = vector_store.similarity_search_with_score(query, k=k)

    logger.debug(
        "Similarity search returned %d results: %s",
        len(results),
        [(doc.metadata.get("name"), round(score, 4)) for doc, score in results],
    )
    return results
