"""
Assembles the UdaPlay multi-agent workflow as a LangGraph StateGraph.

Flow:

    START -> retriever -> evaluator --(sufficient)--> synthesizer -> END
                              \\
                               --(insufficient)--> web_search -> synthesizer -> END

This mirrors the two-tier decision workflow from the architecture doc:
RAG-first, with a Tavily web-search fallback gated by an explicit
confidence evaluation step.
"""

from __future__ import annotations

from langgraph.graph import END, StateGraph

from src.agents import (
    AgentState,
    evaluator_agent,
    retriever_agent,
    route_after_evaluation,
    synthesizer_agent,
    web_search_agent,
)
from src.logger import get_logger

logger = get_logger("graph")


def build_graph():
    logger.info("Building UdaPlay multi-agent StateGraph...")

    workflow = StateGraph(AgentState)

    workflow.add_node("retriever", retriever_agent)
    workflow.add_node("evaluator", evaluator_agent)
    workflow.add_node("web_search", web_search_agent)
    workflow.add_node("synthesizer", synthesizer_agent)

    workflow.set_entry_point("retriever")
    workflow.add_edge("retriever", "evaluator")

    workflow.add_conditional_edges(
        "evaluator",
        route_after_evaluation,
        {
            "synthesizer": "synthesizer",
            "web_search": "web_search",
        },
    )

    workflow.add_edge("web_search", "synthesizer")
    workflow.add_edge("synthesizer", END)

    compiled = workflow.compile()
    logger.info("StateGraph compiled successfully.")
    return compiled


def run_query(query: str) -> dict:
    """Convenience helper: run a single query through the compiled graph."""
    logger.info("=" * 70)
    logger.info("Running UdaPlay agent for query: %r", query)

    graph = build_graph()
    initial_state = {
        "query": query,
        "reasoning_trace": [],
        "used_web_search": False,
    }
    final_state = graph.invoke(initial_state)

    logger.info("Run complete for query: %r", query)
    logger.info("=" * 70)
    return final_state["final_answer"]
