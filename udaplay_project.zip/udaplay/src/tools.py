"""
Core LangChain tools used by the UdaPlay multi-agent system.

  1. retrieve_game       -> queries the local FAISS index (Retriever Agent)
  2. evaluate_retrieval   -> judges whether retrieved context is sufficient (Evaluator Agent)
  3. game_web_search      -> falls back to the Tavily web search API (Web Search Agent)

Each tool logs its inputs/outputs so the full decision trace can be audited.
"""

from __future__ import annotations

import json
from typing import List

from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from tavily import TavilyClient

from src.config import settings
from src.logger import get_logger
from src.schemas import EvaluationResult, GameRecord, RetrievalResult, WebSearchResult
from src.vector_store import load_vector_store, similarity_search

logger = get_logger("tools")

# Lazily-initialized singletons so importing this module doesn't require
# network access / valid credentials (useful for unit tests).
_vector_store = None
_tavily_client = None
_eval_llm = None


def _get_vector_store():
    global _vector_store
    if _vector_store is None:
        _vector_store = load_vector_store()
    return _vector_store


def _get_tavily_client() -> TavilyClient:
    global _tavily_client
    if _tavily_client is None:
        _tavily_client = TavilyClient(api_key=settings.tavily_api_key)
    return _tavily_client


def _get_eval_llm() -> ChatOpenAI:
    global _eval_llm
    if _eval_llm is None:
        _eval_llm = ChatOpenAI(
            model=settings.llm_model,
            temperature=0,
            openai_api_key=settings.openai_api_key,
            openai_api_base=settings.openai_base_url,
        )
    return _eval_llm


# --------------------------------------------------------------------------
# Tool 1: retrieve_game
# --------------------------------------------------------------------------
@tool
def retrieve_game(query: str) -> str:
    """
    Perform semantic search over the internal FAISS video-game database.
    Returns formatted game details (Title, Platform, Genre, Publisher,
    Release Year, Description) for the most relevant matches, or an empty
    result marker if nothing is found.
    """
    logger.info("[retrieve_game] query=%r", query)
    store = _get_vector_store()
    scored_docs = similarity_search(store, query)

    records: List[GameRecord] = []
    lines: List[str] = []
    for doc, score in scored_docs:
        meta = doc.metadata
        records.append(
            GameRecord(
                id=meta.get("id"),
                name=meta.get("name", "Unknown"),
                platform=meta.get("platform", "Unknown"),
                genre=meta.get("genre"),
                publisher=meta.get("publisher"),
                description=meta.get("description"),
                release_year=meta.get("release_year"),
                similarity_score=float(score),
            )
        )
        lines.append(doc.page_content + f"\n(similarity distance: {score:.4f})")

    formatted = "\n\n".join(lines) if lines else "No matching games found in the internal database."
    result = RetrievalResult(query=query, results=records, formatted_context=formatted)

    logger.info(
        "[retrieve_game] found %d result(s) for query=%r", len(records), query
    )
    return result.model_dump_json()


# --------------------------------------------------------------------------
# Tool 2: evaluate_retrieval
# --------------------------------------------------------------------------
@tool
def evaluate_retrieval(query: str, retrieved_docs: str) -> str:
    """
    Evaluate whether the retrieved FAISS content (as a JSON RetrievalResult
    string, or raw formatted text) is relevant and sufficient to answer the
    user's query. Returns a JSON object with confidence_score (0.0-1.0),
    is_sufficient (bool), and reasoning (str).
    """
    logger.info("[evaluate_retrieval] evaluating retrieval for query=%r", query)

    # Accept either a raw RetrievalResult JSON blob or plain text.
    try:
        parsed = json.loads(retrieved_docs)
        context_text = parsed.get("formatted_context", retrieved_docs)
        has_results = bool(parsed.get("results"))
    except (json.JSONDecodeError, TypeError):
        context_text = retrieved_docs
        has_results = bool(retrieved_docs.strip())

    if not has_results or "No matching games found" in context_text:
        evaluation = EvaluationResult(
            confidence_score=0.0,
            is_sufficient=False,
            reasoning="The internal database returned no relevant matches for this query.",
        )
        logger.info("[evaluate_retrieval] empty retrieval -> forcing low confidence")
        return evaluation.model_dump_json()

    llm = _get_eval_llm()
    prompt = (
        "You are a strict evaluator for a RAG system. Given a user query and "
        "retrieved context, decide whether the context is sufficient to fully "
        "and accurately answer the query.\n\n"
        f"User query: {query}\n\n"
        f"Retrieved context:\n{context_text}\n\n"
        "Respond with ONLY a JSON object with exactly these keys: "
        '"confidence_score" (float 0.0-1.0), "is_sufficient" (boolean), '
        '"reasoning" (short string). No markdown, no preamble.'
    )

    response = llm.invoke(prompt)
    raw_text = response.content.strip().strip("`").replace("json\n", "", 1)

    try:
        data = json.loads(raw_text)
        evaluation = EvaluationResult(**data)
    except (json.JSONDecodeError, TypeError, ValueError) as exc:
        logger.warning(
            "[evaluate_retrieval] failed to parse LLM evaluation (%s); defaulting to low confidence",
            exc,
        )
        evaluation = EvaluationResult(
            confidence_score=0.3,
            is_sufficient=False,
            reasoning="Evaluator LLM output could not be parsed; defaulting to a cautious fallback.",
        )

    logger.info(
        "[evaluate_retrieval] confidence=%.2f is_sufficient=%s",
        evaluation.confidence_score,
        evaluation.is_sufficient,
    )
    return evaluation.model_dump_json()


# --------------------------------------------------------------------------
# Tool 3: game_web_search
# --------------------------------------------------------------------------
@tool
def game_web_search(query: str) -> str:
    """
    Invoke the Tavily Search API to fetch real-time or missing web data when
    the internal FAISS evaluation fails or lacks sufficient context. Returns
    a formatted summary of the top web results.
    """
    logger.info("[game_web_search] falling back to Tavily for query=%r", query)
    client = _get_tavily_client()

    response = client.search(
        query=query,
        search_depth="advanced",
        max_results=5,
        include_answer=True,
    )

    raw_results = response.get("results", [])
    tavily_answer = response.get("answer", "")

    lines = []
    if tavily_answer:
        lines.append(f"Summary: {tavily_answer}")
    for item in raw_results:
        lines.append(f"- {item.get('title')}: {item.get('content', '')[:300]} (source: {item.get('url')})")

    formatted = "\n".join(lines) if lines else "No web results found."
    result = WebSearchResult(query=query, formatted_context=formatted, raw_results=raw_results)

    logger.info("[game_web_search] retrieved %d web result(s)", len(raw_results))
    return result.model_dump_json()


ALL_TOOLS = [retrieve_game, evaluate_retrieval, game_web_search]
