"""
UdaPlay multi-agent definitions.

Four cooperating agents, each a node in a LangGraph StateGraph:

  1. RetrieverAgent   - queries FAISS via the retrieve_game tool.
  2. EvaluatorAgent    - scores retrieval quality via evaluate_retrieval.
  3. WebSearchAgent    - fallback web research via game_web_search (Tavily).
  4. SynthesizerAgent  - LLM that composes the final structured answer,
                         citing whichever source(s) were actually used.

Each agent is a plain Python function operating on a shared `AgentState`
TypedDict, which keeps the control flow explicit, debuggable, and easy to
extend -- in line with 2026 best practice of using LangGraph's StateGraph
instead of the deprecated AgentExecutor / initialize_agent APIs.
"""

from __future__ import annotations

import json
from typing import List, Optional, TypedDict

from langchain_core.messages import AIMessage
from langchain_openai import ChatOpenAI

from src.config import settings
from src.logger import get_logger
from src.schemas import EvaluationResult, FinalAnswer, RetrievalResult, SourceType, WebSearchResult
from src.tools import evaluate_retrieval, game_web_search, retrieve_game

logger = get_logger("agents")


class AgentState(TypedDict, total=False):
    """Shared state threaded through every node in the graph."""

    query: str
    retrieval_result: Optional[str]      # JSON string (RetrievalResult)
    evaluation_result: Optional[str]     # JSON string (EvaluationResult)
    web_search_result: Optional[str]     # JSON string (WebSearchResult)
    used_web_search: bool
    final_answer: Optional[dict]         # FinalAnswer.model_dump()
    reasoning_trace: List[str]


# --------------------------------------------------------------------------
# Agent 1: Retriever
# --------------------------------------------------------------------------
def retriever_agent(state: AgentState) -> AgentState:
    logger.info("[RetrieverAgent] START | query=%r", state["query"])

    raw = retrieve_game.invoke({"query": state["query"]})
    state["retrieval_result"] = raw

    trace = state.get("reasoning_trace", [])
    trace.append(f"RetrieverAgent: queried FAISS for '{state['query']}'.")
    state["reasoning_trace"] = trace

    logger.info("[RetrieverAgent] END")
    return state


# --------------------------------------------------------------------------
# Agent 2: Evaluator
# --------------------------------------------------------------------------
def evaluator_agent(state: AgentState) -> AgentState:
    logger.info("[EvaluatorAgent] START")

    raw = evaluate_retrieval.invoke(
        {"query": state["query"], "retrieved_docs": state["retrieval_result"]}
    )
    state["evaluation_result"] = raw

    evaluation = EvaluationResult(**json.loads(raw))
    trace = state.get("reasoning_trace", [])
    trace.append(
        f"EvaluatorAgent: confidence={evaluation.confidence_score:.2f}, "
        f"is_sufficient={evaluation.is_sufficient} -- {evaluation.reasoning}"
    )
    state["reasoning_trace"] = trace

    logger.info(
        "[EvaluatorAgent] END | confidence=%.2f is_sufficient=%s",
        evaluation.confidence_score,
        evaluation.is_sufficient,
    )
    return state


def route_after_evaluation(state: AgentState) -> str:
    """Conditional edge: decide whether to fall back to web search."""
    evaluation = EvaluationResult(**json.loads(state["evaluation_result"]))
    sufficient = evaluation.is_sufficient and evaluation.confidence_score >= settings.confidence_threshold

    decision = "synthesizer" if sufficient else "web_search"
    logger.info(
        "[Router] confidence=%.2f threshold=%.2f -> routing to '%s'",
        evaluation.confidence_score,
        settings.confidence_threshold,
        decision,
    )
    return decision


# --------------------------------------------------------------------------
# Agent 3: Web Search (fallback)
# --------------------------------------------------------------------------
def web_search_agent(state: AgentState) -> AgentState:
    logger.info("[WebSearchAgent] START | query=%r", state["query"])

    raw = game_web_search.invoke({"query": state["query"]})
    state["web_search_result"] = raw
    state["used_web_search"] = True

    trace = state.get("reasoning_trace", [])
    trace.append(f"WebSearchAgent: fell back to Tavily web search for '{state['query']}'.")
    state["reasoning_trace"] = trace

    logger.info("[WebSearchAgent] END")
    return state


# --------------------------------------------------------------------------
# Agent 4: Synthesizer
# --------------------------------------------------------------------------
def synthesizer_agent(state: AgentState) -> AgentState:
    logger.info("[SynthesizerAgent] START")

    llm = ChatOpenAI(
        model=settings.llm_model,
        temperature=0.2,
        openai_api_key=settings.openai_api_key,
        openai_api_base=settings.openai_base_url,
    )

    retrieval = RetrievalResult(**json.loads(state["retrieval_result"]))
    used_web = state.get("used_web_search", False)
    web_result: Optional[WebSearchResult] = None
    if used_web and state.get("web_search_result"):
        web_result = WebSearchResult(**json.loads(state["web_search_result"]))

    context_blocks = [f"INTERNAL DATABASE CONTEXT:\n{retrieval.formatted_context}"]
    if web_result:
        context_blocks.append(f"WEB SEARCH CONTEXT:\n{web_result.formatted_context}")
    full_context = "\n\n".join(context_blocks)

    prompt = (
        "You are UdaPlay, a gaming research assistant. Using ONLY the context "
        "below, answer the user's query clearly and concisely. Highlight Key "
        "Details (Platform, Publisher, Release Date) when available.\n\n"
        f"User query: {state['query']}\n\n"
        f"{full_context}\n\n"
        "Write a short, well-formatted answer for the end user."
    )

    response = llm.invoke(prompt)
    answer_text = response.content.strip()

    if used_web and not retrieval.is_empty:
        source = SourceType.HYBRID
    elif used_web:
        source = SourceType.WEB_SEARCH
    else:
        source = SourceType.INTERNAL_DB

    confidence = None
    if state.get("evaluation_result"):
        confidence = EvaluationResult(**json.loads(state["evaluation_result"])).confidence_score

    key_details = {}
    if retrieval.results:
        top = retrieval.results[0]
        key_details = {
            "Platform": top.platform,
            "Publisher": top.publisher,
            "Release Year": top.release_year,
        }

    final = FinalAnswer(
        query=state["query"],
        answer=answer_text,
        key_details=key_details,
        source=source,
        confidence_score=confidence,
        reasoning_trace=state.get("reasoning_trace", []),
    )
    state["final_answer"] = final.model_dump()

    logger.info("[SynthesizerAgent] END | source=%s", source.value)
    return state
